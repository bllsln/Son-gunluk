import 'package:flutter_test/flutter_test.dart';
import 'package:gunluk_mobile/log_calc.dart';

DateTime d(int day, int h, int m) => DateTime(2026, 3, day, h, m);

void main() {
  test('Görsel örneği: 06:00-17:45, 45 = 12:00-17:45', () {
    final c = calcLog(
        start: d(9, 6, 0), end: d(9, 17, 45), s45: d(9, 12, 0), e45: d(9, 17, 45));
    expect(c.ok, true);
    expect(c.total, 705);
    expect(c.minutes45, 345);
    expect(c.minutes4011, 360);
    expect(c.night, 0);
  });

  test('Alt aralık yoksa 4011 tüm süredir; gece ana aralıktan', () {
    final c = calcLog(start: d(1, 13, 0), end: d(2, 5, 15));
    expect(c.total, 975);
    expect(c.minutes4011, 975);
    expect(c.night, 555);
    expect(c.nightExcess, 105);
  });

  test('Tren Şefliği alt aralığı ayrı toplanır', () {
    final c = calcLog(
        start: d(1, 8, 0), end: d(1, 16, 0), sSef: d(1, 14, 0), eSef: d(1, 16, 0));
    expect(c.minutesSef, 120);
    expect(c.minutes4011, 360);
    expect(c.minutes45, 0);
  });

  test('Gece yarısını geçen alt aralık doğru tarihe çözülür', () {
    final start = d(1, 22, 0);
    final end = d(2, 8, 0);
    final s = resolveSubStart(start, 2, 0);
    final e = resolveSubEnd(s, 5, 0);
    expect(s, d(2, 2, 0));
    expect(e, d(2, 5, 0));
    final c = calcLog(start: start, end: end, s45: s, e45: e);
    expect(c.ok, true);
    expect(c.minutes45, 180);
    expect(c.minutes4011, 420);
    expect(c.night, 480);
  });

  test('Aralık dışı alt aralık hata verir', () {
    final c = calcLog(
        start: d(1, 8, 0), end: d(1, 16, 0), s45: d(1, 7, 0), e45: d(1, 10, 0));
    expect(c.ok, false);
  });

  test('45 ile Şeflik çakışması hata verir', () {
    final c = calcLog(
        start: d(1, 8, 0),
        end: d(1, 16, 0),
        s45: d(1, 10, 0),
        e45: d(1, 13, 0),
        sSef: d(1, 12, 0),
        eSef: d(1, 15, 0));
    expect(c.ok, false);
  });

  test('Toplamı aşan alt aralıklar hata verir', () {
    final c = calcLog(
        start: d(1, 8, 0),
        end: d(1, 12, 0),
        s45: d(1, 8, 0),
        e45: d(1, 12, 0),
        sSef: d(1, 8, 0),
        eSef: d(1, 10, 0));
    expect(c.ok, false);
  });

  test('Bitiş başlangıçtan önce ise hata', () {
    final c = calcLog(start: d(1, 10, 0), end: d(1, 9, 0));
    expect(c.ok, false);
  });
}
