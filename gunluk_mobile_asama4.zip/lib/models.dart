/// Günlük içindeki olay satırı (saat, yer, olay).
class EventItem {
  String time; // "HH:mm"
  String place;
  String text;
  EventItem({required this.time, this.place = '', this.text = ''});

  static EventItem fromMap(Map<String, Object?> m) => EventItem(
        time: (m['at_time'] as String?) ?? '',
        place: (m['place'] as String?) ?? '',
        text: (m['text'] as String?) ?? '',
      );
}

/// Hat / görev / tren değişimi kaydı.
class ChangeItem {
  String time; // "HH:mm"
  String place;
  String prevTrain;
  String newTrain;
  String text;
  ChangeItem({
    required this.time,
    this.place = '',
    this.prevTrain = '',
    this.newTrain = '',
    this.text = '',
  });

  static ChangeItem fromMap(Map<String, Object?> m) => ChangeItem(
        time: (m['at_time'] as String?) ?? '',
        place: (m['place'] as String?) ?? '',
        prevTrain: (m['prev_train'] as String?) ?? '',
        newTrain: (m['new_train'] as String?) ?? '',
        text: (m['text'] as String?) ?? '',
      );
}

/// Bir günlük kaydı.
/// Ana aralık [start]-[end] günlük toplam çalışmadır.
/// 45 ve Tren Şefliği, bu aralığın içindeki isteğe bağlı alt aralıklardır.
/// 4011 = toplam − 45 − Tren Şefliği.
class LogEntry {
  int? id;
  String title;
  String trainNo;
  String locoNo;
  String note;
  DateTime start;
  DateTime end;
  DateTime? s45;
  DateTime? e45;
  DateTime? sSef;
  DateTime? eSef;
  final List<EventItem> events;
  final List<ChangeItem> changes;
  final List<String> crew;

  LogEntry({
    this.id,
    required this.start,
    required this.end,
    this.title = '',
    this.trainNo = '',
    this.locoNo = '',
    this.note = '',
    this.s45,
    this.e45,
    this.sSef,
    this.eSef,
    List<EventItem>? events,
    List<ChangeItem>? changes,
    List<String>? crew,
  })  : events = events ?? [],
        changes = changes ?? [],
        crew = crew ?? [];

  Map<String, Object?> toMap() => {
        'title': title,
        'train_no': trainNo,
        'loco_no': locoNo,
        'start_at': start.toIso8601String(),
        'end_at': end.toIso8601String(),
        's45_start': s45?.toIso8601String(),
        's45_end': e45?.toIso8601String(),
        'sef_start': sSef?.toIso8601String(),
        'sef_end': eSef?.toIso8601String(),
        'note': note,
        'updated_at': DateTime.now().toIso8601String(),
      };

  static DateTime? _dt(Object? v) =>
      v == null ? null : DateTime.parse(v as String);

  static LogEntry fromMap(
    Map<String, Object?> m, {
    required List<EventItem> events,
    required List<ChangeItem> changes,
    required List<String> crew,
  }) =>
      LogEntry(
        id: m['id'] as int,
        title: (m['title'] as String?) ?? '',
        trainNo: (m['train_no'] as String?) ?? '',
        locoNo: (m['loco_no'] as String?) ?? '',
        note: (m['note'] as String?) ?? '',
        start: DateTime.parse(m['start_at'] as String),
        end: DateTime.parse(m['end_at'] as String),
        s45: _dt(m['s45_start']),
        e45: _dt(m['s45_end']),
        sSef: _dt(m['sef_start']),
        eSef: _dt(m['sef_end']),
        events: events,
        changes: changes,
        crew: crew,
      );
}
