import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'models.dart';

/// Yerel SQLite veri tabanı (v2: günlük kayıtları).
class Db {
  static Database? _db;

  static Future<Database> _open() async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'gunluk_mobile.db');
    _db = await openDatabase(
      path,
      version: 2,
      onCreate: (d, v) async => _createV2(d),
      onUpgrade: (d, oldV, newV) async {
        if (oldV < 2) {
          await _createV2(d);
          await _migrateTasks(d);
        }
      },
    );
    return _db!;
  }

  static Future<void> _createV2(Database d) async {
    await d.execute('''
CREATE TABLE logs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT, train_no TEXT, loco_no TEXT,
  start_at TEXT NOT NULL, end_at TEXT NOT NULL,
  s45_start TEXT, s45_end TEXT, sef_start TEXT, sef_end TEXT,
  note TEXT, created_at TEXT, updated_at TEXT
)''');
    await d.execute('''
CREATE TABLE events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  log_id INTEGER NOT NULL, at_time TEXT, place TEXT, text TEXT
)''');
    await d.execute('''
CREATE TABLE changes(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  log_id INTEGER NOT NULL, at_time TEXT, place TEXT,
  prev_train TEXT, new_train TEXT, text TEXT
)''');
    await d.execute('''
CREATE TABLE crew(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  log_id INTEGER NOT NULL, name TEXT
)''');
  }

  /// Aşama 3'te girilmiş görevleri günlüğe taşır (eski tablo silinmez).
  static Future<void> _migrateTasks(Database d) async {
    await d.execute('''
INSERT INTO logs(title, train_no, loco_no, start_at, end_at,
  s45_start, s45_end, sef_start, sef_end, note, created_at, updated_at)
SELECT '', train_no, '', start_at, end_at,
  CASE WHEN model = '45' THEN start_at END,
  CASE WHEN model = '45' THEN end_at END,
  CASE WHEN model = 'Tren Şefliği' THEN start_at END,
  CASE WHEN model = 'Tren Şefliği' THEN end_at END,
  TRIM(COALESCE(note, '') || ' ' || COALESCE(from_st, '') ||
    CASE WHEN COALESCE(to_st, '') <> '' THEN ' → ' || to_st ELSE '' END),
  created_at, updated_at
FROM tasks WHERE COALESCE(status, '') <> 'Görevsiz'
''');
  }

  static Future<List<LogEntry>> all() async {
    final d = await _open();
    final logs = await d.query('logs', orderBy: 'start_at ASC');
    final evs = await d.query('events', orderBy: 'id ASC');
    final chs = await d.query('changes', orderBy: 'id ASC');
    final crw = await d.query('crew', orderBy: 'id ASC');
    return logs.map((m) {
      final id = m['id'] as int;
      return LogEntry.fromMap(
        m,
        events: evs
            .where((r) => r['log_id'] == id)
            .map(EventItem.fromMap)
            .toList(),
        changes: chs
            .where((r) => r['log_id'] == id)
            .map(ChangeItem.fromMap)
            .toList(),
        crew: crw
            .where((r) => r['log_id'] == id)
            .map((r) => (r['name'] as String?) ?? '')
            .toList(),
      );
    }).toList();
  }

  /// Yeni kayıt ekler veya yalnızca verilen kimlikli kaydı günceller.
  static Future<void> save(LogEntry e) async {
    final d = await _open();
    await d.transaction((txn) async {
      final int id;
      if (e.id == null) {
        final m = e.toMap();
        m['created_at'] = DateTime.now().toIso8601String();
        id = await txn.insert('logs', m);
      } else {
        id = e.id!;
        await txn.update('logs', e.toMap(), where: 'id = ?', whereArgs: [id]);
        for (final t in ['events', 'changes', 'crew']) {
          await txn.delete(t, where: 'log_id = ?', whereArgs: [id]);
        }
      }
      for (final v in e.events) {
        await txn.insert('events',
            {'log_id': id, 'at_time': v.time, 'place': v.place, 'text': v.text});
      }
      for (final v in e.changes) {
        await txn.insert('changes', {
          'log_id': id,
          'at_time': v.time,
          'place': v.place,
          'prev_train': v.prevTrain,
          'new_train': v.newTrain,
          'text': v.text,
        });
      }
      for (final n in e.crew) {
        await txn.insert('crew', {'log_id': id, 'name': n});
      }
    });
  }

  /// Yalnızca verilen kimlikli günlüğü ve ona bağlı satırları siler.
  static Future<void> delete(int id) async {
    final d = await _open();
    await d.transaction((txn) async {
      for (final t in ['events', 'changes', 'crew']) {
        await txn.delete(t, where: 'log_id = ?', whereArgs: [id]);
      }
      await txn.delete('logs', where: 'id = ?', whereArgs: [id]);
    });
  }
}
