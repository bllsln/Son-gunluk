import 'domain/duration_calc.dart';

/// Günlük hesabı. Dakika tabanlıdır.
/// toplam = ana aralık; 4011 = toplam − 45 − Tren Şefliği.
/// Gece ve gece aşımı ana aralık üzerinden hesaplanır (toplamın alt kümesidir).
class LogCalc {
  final int total;
  final int night;
  final int nightExcess;
  final int minutes4011;
  final int minutes45;
  final int minutesSef;
  final List<String> errors;

  const LogCalc({
    required this.total,
    required this.night,
    required this.nightExcess,
    required this.minutes4011,
    required this.minutes45,
    required this.minutesSef,
    required this.errors,
  });

  bool get ok => errors.isEmpty;
}

/// Alt aralığın başlangıç saatini ana başlangıca göre tarihe çevirir.
/// Ana başlangıçtan önceye düşerse ertesi güne kaydırır.
DateTime resolveSubStart(DateTime mainStart, int hour, int minute) {
  var c = DateTime(mainStart.year, mainStart.month, mainStart.day, hour, minute);
  if (c.isBefore(mainStart)) {
    c = DateTime(mainStart.year, mainStart.month, mainStart.day + 1, hour, minute);
  }
  return c;
}

/// Alt aralığın bitiş saatini, alt başlangıçtan sonraki ilk uygun ana çevirir.
DateTime resolveSubEnd(DateTime subStart, int hour, int minute) {
  var c = DateTime(subStart.year, subStart.month, subStart.day, hour, minute);
  if (!c.isAfter(subStart)) {
    c = DateTime(subStart.year, subStart.month, subStart.day + 1, hour, minute);
  }
  return c;
}

LogCalc calcLog({
  required DateTime start,
  required DateTime end,
  DateTime? s45,
  DateTime? e45,
  DateTime? sSef,
  DateTime? eSef,
}) {
  if (!end.isAfter(start)) {
    return const LogCalc(
      total: 0,
      night: 0,
      nightExcess: 0,
      minutes4011: 0,
      minutes45: 0,
      minutesSef: 0,
      errors: ['Bitiş, başlangıçtan sonra olmalıdır.'],
    );
  }
  final errors = <String>[];
  final base = calculateTask(start, end);

  int sub(DateTime? s, DateTime? e, String name) {
    if (s == null || e == null) return 0;
    if (!e.isAfter(s)) {
      errors.add('$name bitişi başlangıçtan sonra olmalıdır.');
      return 0;
    }
    if (s.isBefore(start) || e.isAfter(end)) {
      errors.add('$name aralığı günlük çalışma aralığının dışında.');
    }
    return e.difference(s).inMinutes;
  }

  final m45 = sub(s45, e45, '45');
  final mSef = sub(sSef, eSef, 'Tren Şefliği');
  if (s45 != null &&
      e45 != null &&
      sSef != null &&
      eSef != null &&
      s45.isBefore(eSef) &&
      sSef.isBefore(e45)) {
    errors.add('45 ile Tren Şefliği aralıkları çakışıyor.');
  }
  var m4011 = base.totalMinutes - m45 - mSef;
  if (m4011 < 0) {
    errors.add('45 ve Tren Şefliği toplamı günlük çalışmayı aşıyor.');
    m4011 = 0;
  }
  return LogCalc(
    total: base.totalMinutes,
    night: base.nightMinutes,
    nightExcess: base.nightExcessMinutes,
    minutes4011: m4011,
    minutes45: m45,
    minutesSef: mSef,
    errors: errors,
  );
}
