import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';

import 'db.dart';
import 'domain/duration_calc.dart';
import 'log_calc.dart';
import 'logo_data.dart';
import 'models.dart';

const gold = Color(0xFFF2A91B);
const bgDark = Color(0xFF0E0E10);
const cardDark = Color(0xFF1B1B1F);
const borderGold = Color(0x59F2A91B);
const danger = Color(0xFFFF5A4D);
const okGreen = Color(0xFF4CD27B);
const grey = Color(0xFF9A9AA2);

const monthNames = [
  'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran',
  'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'
];

final Uint8List _logoBytes = base64Decode(logoBase64);

String two(int n) => n.toString().padLeft(2, '0');
String hhmm(int minutes) => '${two(minutes ~/ 60)}:${two(minutes % 60)}';
String fmtTod(TimeOfDay t) => '${two(t.hour)}:${two(t.minute)}';
String fmtTime(DateTime d) => '${two(d.hour)}:${two(d.minute)}';
String fmtLong(DateTime d) => '${two(d.day)} ${monthNames[d.month - 1]} ${d.year}';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const GunlukMobileApp());
}

class GunlukMobileApp extends StatelessWidget {
  const GunlukMobileApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Makinist Günlüğü',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.dark,
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bgDark,
        colorScheme: const ColorScheme.dark(
          primary: gold,
          onPrimary: Colors.black,
          secondary: gold,
          surface: cardDark,
          onSurface: Colors.white,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: bgDark,
          foregroundColor: gold,
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            backgroundColor: gold,
            foregroundColor: Colors.black,
            minimumSize: const Size.fromHeight(48),
            textStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
        ),
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(),
          enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: borderGold)),
          focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: gold)),
          labelStyle: TextStyle(color: gold),
        ),
      ),
      home: const RootPage(),
    );
  }
}

Widget panel(Widget child, {EdgeInsets padding = const EdgeInsets.all(12), Color? color}) =>
    Container(
      margin: const EdgeInsets.symmetric(vertical: 5),
      padding: padding,
      decoration: BoxDecoration(
        color: color ?? cardDark,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: borderGold),
      ),
      child: child,
    );

Widget stat(String label, String value, {Color color = gold}) => Column(
      children: [
        Text(label, style: const TextStyle(fontSize: 11, color: Colors.white70)),
        const SizedBox(height: 2),
        Text(value,
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
      ],
    );

class RootPage extends StatefulWidget {
  const RootPage({super.key});

  @override
  State<RootPage> createState() => _RootPageState();
}

class _RootPageState extends State<RootPage> {
  int _tab = 0;
  DateTime _month = DateTime(DateTime.now().year, DateTime.now().month);
  List<LogEntry> _all = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final l = await Db.all();
    if (!mounted) return;
    setState(() {
      _all = l;
      _loading = false;
    });
  }

  // Kural (doğrulanmadı): günlük, BAŞLANGIÇ tarihinin ayına sayılır.
  List<LogEntry> get _monthLogs => _all
      .where((e) => e.start.year == _month.year && e.start.month == _month.month)
      .toList();

  void _shift(int d) =>
      setState(() => _month = DateTime(_month.year, _month.month + d));

  Future<void> _openForm([LogEntry? e]) async {
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => LogForm(entry: e, all: _all)),
    );
    if (saved == true) _load();
  }

  LogCalc _calc(LogEntry e) => calcLog(
      start: e.start, end: e.end, s45: e.s45, e45: e.e45, sSef: e.sSef, eSef: e.eSef);

  int _restViolations() {
    final s = [..._all]..sort((a, b) => a.start.compareTo(b.start));
    var n = 0;
    for (var i = 1; i < s.length; i++) {
      final c = s[i];
      if (c.start.year == _month.year &&
          c.start.month == _month.month &&
          c.start.difference(s[i - 1].end).inMinutes < 660) {
        n++;
      }
    }
    return n;
  }

  Widget _monthBar() => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(onPressed: () => _shift(-1), icon: const Icon(Icons.chevron_left, color: gold)),
          Text('${monthNames[_month.month - 1]} ${_month.year}',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          IconButton(onPressed: () => _shift(1), icon: const Icon(Icons.chevron_right, color: gold)),
        ],
      );

  Widget _header() => Row(
        children: [
          Image.memory(_logoBytes, height: 64),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('MAKİNİST GÜNLÜĞÜ',
                    style: TextStyle(color: gold, fontSize: 22, fontWeight: FontWeight.w900)),
                Text('RAYLAR ARASINDA',
                    style: TextStyle(letterSpacing: 3, fontSize: 12, color: Colors.white70)),
              ],
            ),
          ),
        ],
      );

  Widget _dailyTab() {
    final logs = _monthLogs.reversed.toList();
    return ListView(
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 96),
      children: [
        _header(),
        _monthBar(),
        if (logs.isEmpty)
          const Padding(
            padding: EdgeInsets.all(32),
            child: Center(child: Text('Bu ay günlük kaydı yok.')),
          ),
        for (final e in logs) _logCard(e),
      ],
    );
  }

  Widget _logCard(LogEntry e) {
    final c = _calc(e);
    final nextDay = DateTime(e.end.year, e.end.month, e.end.day)
        .isAfter(DateTime(e.start.year, e.start.month, e.start.day));
    return InkWell(
      onTap: () => _openForm(e),
      child: panel(
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(fmtLong(e.start),
                    style: const TextStyle(color: gold, fontWeight: FontWeight.bold)),
                Text('${fmtTime(e.start)} → ${fmtTime(e.end)}${nextDay ? ' (+1)' : ''}',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
            if (e.title.isNotEmpty) Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(e.title),
            ),
            if (e.trainNo.isNotEmpty || e.locoNo.isNotEmpty)
              Text('Tren ${e.trainNo}   Lokomotif ${e.locoNo}',
                  style: const TextStyle(color: grey, fontSize: 12)),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                stat('TOPLAM', hhmm(c.total)),
                stat('4011', hhmm(c.minutes4011)),
                if (c.minutes45 > 0) stat('45', hhmm(c.minutes45)),
                if (c.minutesSef > 0) stat('ŞEF', hhmm(c.minutesSef)),
                stat('GECE', hhmm(c.night)),
              ],
            ),
            if (!c.ok)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(c.errors.first, style: const TextStyle(color: danger)),
              ),
          ],
        ),
      ),
    );
  }

  Widget _monthlyTab() {
    final logs = _monthLogs;
    var total = 0, m4011 = 0, m45 = 0, mSef = 0, night = 0, excess = 0;
    for (final e in logs) {
      final c = _calc(e);
      if (!c.ok) continue;
      total += c.total;
      m4011 += c.minutes4011;
      m45 += c.minutes45;
      mSef += c.minutesSef;
      night += c.night;
      excess += c.nightExcess;
    }
    final rest = _restViolations();
    Widget big(String label, String value, {Color color = gold}) => panel(
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(label, style: const TextStyle(fontSize: 16)),
              Text(value,
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: color)),
            ],
          ),
        );
    return ListView(
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 24),
      children: [
        const Text('AYLIK ÖZET',
            style: TextStyle(color: gold, fontSize: 20, fontWeight: FontWeight.w900)),
        _monthBar(),
        big('Toplam görev', '${logs.length}'),
        big('Toplam çalışma', hhmm(total)),
        big('4011', hhmm(m4011)),
        big('45', hhmm(m45)),
        big('Tren Şefliği', hhmm(mSef)),
        big('Gece çalışması', hhmm(night), color: const Color(0xFF8AA4FF)),
        big('Gece 7 sa 30 dk aşımı', hhmm(excess)),
        big('Dinlenme ihlali (11 sa)', '$rest', color: rest > 0 ? danger : okGreen),
        const Padding(
          padding: EdgeInsets.all(8),
          child: Text(
            'Gece, toplamın alt kümesidir (iki kez sayılmaz). Görevsiz yolculuk, '
            'hafta tatili, 35 saatlik dinlenme, izinler ve aylık hedef sonraki aşamalarda eklenecek.',
            style: TextStyle(fontSize: 12, color: grey),
          ),
        ),
      ],
    );
  }

  Widget _soon(String title) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(title,
                  style: const TextStyle(color: gold, fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              const Text('Bu bölüm sonraki aşamada eklenecek.', textAlign: TextAlign.center),
            ],
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final pages = [
      _dailyTab(),
      _monthlyTab(),
      _soon('PDF RAPOR'),
      _soon('AYARLAR'),
    ];
    return Scaffold(
      body: SafeArea(
        child: _loading ? const Center(child: CircularProgressIndicator()) : pages[_tab],
      ),
      floatingActionButton: _tab == 0
          ? FloatingActionButton.extended(
              onPressed: () => _openForm(),
              backgroundColor: gold,
              foregroundColor: Colors.black,
              icon: const Icon(Icons.add),
              label: const Text('Günlük kaydı'),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        backgroundColor: cardDark,
        indicatorColor: borderGold,
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.event_note), label: 'GÜNLÜK'),
          NavigationDestination(icon: Icon(Icons.calendar_month), label: 'AYLIK'),
          NavigationDestination(icon: Icon(Icons.picture_as_pdf), label: 'RAPOR'),
          NavigationDestination(icon: Icon(Icons.settings), label: 'AYARLAR'),
        ],
      ),
    );
  }
}

class LogForm extends StatefulWidget {
  final LogEntry? entry;
  final List<LogEntry> all;
  const LogForm({super.key, this.entry, required this.all});

  @override
  State<LogForm> createState() => _LogFormState();
}

class _LogFormState extends State<LogForm> {
  late DateTime _date;
  late TimeOfDay _st;
  late TimeOfDay _et;
  bool _nextDay = false;
  bool _use45 = false;
  bool _useSef = false;
  TimeOfDay _s45 = const TimeOfDay(hour: 12, minute: 0);
  TimeOfDay _e45 = const TimeOfDay(hour: 16, minute: 0);
  TimeOfDay _sSef = const TimeOfDay(hour: 12, minute: 0);
  TimeOfDay _eSef = const TimeOfDay(hour: 16, minute: 0);
  final _title = TextEditingController();
  final _train = TextEditingController();
  final _loco = TextEditingController();
  final _note = TextEditingController();
  final _crewCtl = TextEditingController();
  final List<EventItem> _events = [];
  final List<ChangeItem> _changes = [];
  final List<String> _crew = [];

  @override
  void initState() {
    super.initState();
    final e = widget.entry;
    if (e != null) {
      _date = DateTime(e.start.year, e.start.month, e.start.day);
      _st = TimeOfDay.fromDateTime(e.start);
      _et = TimeOfDay.fromDateTime(e.end);
      _nextDay = DateTime(e.end.year, e.end.month, e.end.day).isAfter(_date);
      if (e.s45 != null && e.e45 != null) {
        _use45 = true;
        _s45 = TimeOfDay.fromDateTime(e.s45!);
        _e45 = TimeOfDay.fromDateTime(e.e45!);
      }
      if (e.sSef != null && e.eSef != null) {
        _useSef = true;
        _sSef = TimeOfDay.fromDateTime(e.sSef!);
        _eSef = TimeOfDay.fromDateTime(e.eSef!);
      }
      _title.text = e.title;
      _train.text = e.trainNo;
      _loco.text = e.locoNo;
      _note.text = e.note;
      _events.addAll(e.events);
      _changes.addAll(e.changes);
      _crew.addAll(e.crew);
    } else {
      final n = DateTime.now();
      _date = DateTime(n.year, n.month, n.day);
      _st = const TimeOfDay(hour: 8, minute: 0);
      _et = const TimeOfDay(hour: 16, minute: 0);
    }
  }

  @override
  void dispose() {
    _title.dispose();
    _train.dispose();
    _loco.dispose();
    _note.dispose();
    _crewCtl.dispose();
    super.dispose();
  }

  DateTime get _startDT =>
      DateTime(_date.year, _date.month, _date.day, _st.hour, _st.minute);
  DateTime get _endDT => DateTime(
      _date.year, _date.month, _date.day + (_nextDay ? 1 : 0), _et.hour, _et.minute);

  DateTime? get _s45DT =>
      _use45 ? resolveSubStart(_startDT, _s45.hour, _s45.minute) : null;
  DateTime? get _e45DT {
    final s = _s45DT;
    return s == null ? null : resolveSubEnd(s, _e45.hour, _e45.minute);
  }

  DateTime? get _sSefDT =>
      _useSef ? resolveSubStart(_startDT, _sSef.hour, _sSef.minute) : null;
  DateTime? get _eSefDT {
    final s = _sSefDT;
    return s == null ? null : resolveSubEnd(s, _eSef.hour, _eSef.minute);
  }

  LogCalc _calc() => calcLog(
      start: _startDT,
      end: _endDT,
      s45: _s45DT,
      e45: _e45DT,
      sSef: _sSefDT,
      eSef: _eSefDT);

  int _mins(TimeOfDay t) => t.hour * 60 + t.minute;

  Future<TimeOfDay?> _pickTime(TimeOfDay init) => showTimePicker(
        context: context,
        initialTime: init,
        builder: (c, child) => MediaQuery(
          data: MediaQuery.of(c).copyWith(alwaysUse24HourFormat: true),
          child: child!,
        ),
      );

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (d != null) setState(() => _date = d);
  }

  Widget _timeBox(String label, TimeOfDay t, ValueChanged<TimeOfDay> onPicked) {
    return Expanded(
      child: InkWell(
        onTap: () async {
          final v = await _pickTime(t);
          if (v != null) onPicked(v);
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: borderGold),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: const TextStyle(color: gold, fontSize: 12)),
              Text(fmtTod(t),
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }

  void _autoNextDay() => _nextDay = _mins(_et) <= _mins(_st);

  List<String> _restWarnings() {
    final w = <String>[];
    final id = widget.entry?.id;
    final others = widget.all.where((o) => o.id != id).toList();
    LogEntry? prev, next;
    for (final o in others) {
      if (!o.end.isAfter(_startDT) && (prev == null || o.end.isAfter(prev.end))) prev = o;
      if (!o.start.isBefore(_endDT) && (next == null || o.start.isBefore(next.start))) next = o;
    }
    if (prev != null) {
      final r = _startDT.difference(prev.end).inMinutes;
      if (r < 660) w.add('Dinlenme ihlali: önceki günlükten sonra ${hhmm(r)} (11 saatten az).');
    }
    if (next != null) {
      final r = next.start.difference(_endDT).inMinutes;
      if (r < 660) w.add('Dinlenme ihlali: sonraki günlüğe ${hhmm(r)} var (11 saatten az).');
    }
    for (final o in others) {
      if (_startDT.isBefore(o.end) && o.start.isBefore(_endDT)) {
        w.add('Çakışma: ${fmtLong(o.start)} ${fmtTime(o.start)}–${fmtTime(o.end)} günlüğüyle saatler kesişiyor.');
      }
    }
    return w;
  }

  Future<void> _save() async {
    final c = _calc();
    if (!c.ok) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(c.errors.first)));
      return;
    }
    final e = LogEntry(
      id: widget.entry?.id,
      start: _startDT,
      end: _endDT,
      title: _title.text.trim(),
      trainNo: _train.text.trim(),
      locoNo: _loco.text.trim(),
      note: _note.text.trim(),
      s45: _s45DT,
      e45: _e45DT,
      sSef: _sSefDT,
      eSef: _eSefDT,
      events: _events,
      changes: _changes,
      crew: _crew,
    );
    await Db.save(e);
    if (!mounted) return;
    Navigator.pop(context, true);
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Günlük silinsin mi?'),
        content: const Text('Yalnızca bu günlük kaydı silinir.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Sil')),
        ],
      ),
    );
    if (ok != true) return;
    await Db.delete(widget.entry!.id!);
    if (!mounted) return;
    Navigator.pop(context, true);
  }

  Future<void> _addEvent() async {
    var t = TimeOfDay.now();
    final place = TextEditingController();
    final text = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setS) => AlertDialog(
          title: const Text('Olay ekle'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Saat'),
                  trailing: Text(fmtTod(t),
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  onTap: () async {
                    final v = await _pickTime(t);
                    if (v != null) setS(() => t = v);
                  },
                ),
                TextField(controller: place, decoration: const InputDecoration(labelText: 'Yer')),
                const SizedBox(height: 8),
                TextField(
                    controller: text,
                    decoration: const InputDecoration(labelText: 'Olay'),
                    maxLines: 2),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')),
            FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(96, 44)),
              onPressed: () => Navigator.pop(c, true),
              child: const Text('KAYDET'),
            ),
          ],
        ),
      ),
    );
    if (ok == true && (place.text.trim().isNotEmpty || text.text.trim().isNotEmpty)) {
      setState(() {
        _events.add(EventItem(time: fmtTod(t), place: place.text.trim(), text: text.text.trim()));
        _events.sort((a, b) => a.time.compareTo(b.time));
      });
    }
  }

  Future<void> _addChange() async {
    var t = TimeOfDay.now();
    final place = TextEditingController();
    final prev = TextEditingController(text: _train.text);
    final next = TextEditingController();
    final text = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setS) => AlertDialog(
          title: const Text('Hat / görev / tren değişimi'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Saat'),
                  trailing: Text(fmtTod(t),
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  onTap: () async {
                    final v = await _pickTime(t);
                    if (v != null) setS(() => t = v);
                  },
                ),
                TextField(controller: place, decoration: const InputDecoration(labelText: 'Değişim yeri')),
                const SizedBox(height: 8),
                TextField(controller: prev, decoration: const InputDecoration(labelText: 'Önceki tren no')),
                const SizedBox(height: 8),
                TextField(controller: next, decoration: const InputDecoration(labelText: 'Yeni tren no')),
                const SizedBox(height: 8),
                TextField(
                    controller: text,
                    decoration: const InputDecoration(labelText: 'Açıklama'),
                    maxLines: 2),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')),
            FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(96, 44)),
              onPressed: () => Navigator.pop(c, true),
              child: const Text('KAYDET'),
            ),
          ],
        ),
      ),
    );
    if (ok == true) {
      setState(() {
        _changes.add(ChangeItem(
          time: fmtTod(t),
          place: place.text.trim(),
          prevTrain: prev.text.trim(),
          newTrain: next.text.trim(),
          text: text.text.trim(),
        ));
        _changes.sort((a, b) => a.time.compareTo(b.time));
      });
    }
  }

  void _addCrew() {
    final n = _crewCtl.text.trim();
    if (n.isEmpty) return;
    setState(() {
      _crew.add(n);
      _crewCtl.clear();
    });
  }

  Widget _sectionTitle(String s) => Padding(
        padding: const EdgeInsets.only(top: 14, bottom: 4),
        child: Text(s, style: const TextStyle(color: gold, fontWeight: FontWeight.w900, fontSize: 15)),
      );

  Widget _subRange(String label, bool on, ValueChanged<bool> setOn, TimeOfDay s,
      TimeOfDay e, ValueChanged<TimeOfDay> setS, ValueChanged<TimeOfDay> setE) {
    return panel(Column(
      children: [
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: Text(label),
          value: on,
          activeThumbColor: gold,
          onChanged: (v) => setState(() => setOn(v)),
        ),
        if (on)
          Row(
            children: [
              _timeBox('Başlangıç', s, (v) => setState(() => setS(v))),
              const SizedBox(width: 10),
              _timeBox('Bitiş', e, (v) => setState(() => setE(v))),
            ],
          ),
      ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    final c = _calc();
    final warnings = _restWarnings();
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.entry == null ? 'GÜNLÜK KAYIT' : 'GÜNLÜĞÜ DÜZENLE',
            style: const TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          if (widget.entry != null)
            IconButton(onPressed: _delete, icon: const Icon(Icons.delete_outline, color: danger)),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(14, 4, 14, 32),
        children: [
          panel(
            InkWell(
              onTap: _pickDate,
              child: Row(
                children: [
                  const Icon(Icons.calendar_month, color: gold),
                  const SizedBox(width: 10),
                  Text(fmtLong(_date),
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const Spacer(),
                  const Icon(Icons.edit, color: gold, size: 18),
                ],
              ),
            ),
          ),
          const SizedBox(height: 6),
          TextField(
              controller: _title,
              decoration: const InputDecoration(labelText: 'Görev başlığı')),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                  child: TextField(
                      controller: _train,
                      decoration: const InputDecoration(labelText: 'Tren'))),
              const SizedBox(width: 10),
              Expanded(
                  child: TextField(
                      controller: _loco,
                      decoration: const InputDecoration(labelText: 'Lokomotif'))),
            ],
          ),
          _sectionTitle('GÜNLÜK ÇALIŞMA'),
          Row(
            children: [
              _timeBox('Başlangıç', _st, (v) => setState(() {
                    _st = v;
                    _autoNextDay();
                  })),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 8),
                child: Icon(Icons.arrow_forward, color: gold),
              ),
              _timeBox('Bitiş', _et, (v) => setState(() {
                    _et = v;
                    _autoNextDay();
                  })),
            ],
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Bitiş ertesi gün'),
            value: _nextDay,
            activeThumbColor: gold,
            onChanged: (v) => setState(() => _nextDay = v),
          ),
          _subRange('45 modeli çalışması var', _use45, (v) => _use45 = v, _s45, _e45,
              (v) => _s45 = v, (v) => _e45 = v),
          _subRange('Tren Şefliği çalışması var', _useSef, (v) => _useSef = v, _sSef,
              _eSef, (v) => _sSef = v, (v) => _eSef = v),
          _sectionTitle('OLAYLAR'),
          FilledButton.icon(
            onPressed: _addEvent,
            icon: const Icon(Icons.add),
            label: const Text('OLAY EKLE'),
          ),
          for (var i = 0; i < _events.length; i++)
            panel(
              Row(
                children: [
                  Text(_events[i].time,
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (_events[i].place.isNotEmpty)
                          Text(_events[i].place, style: const TextStyle(color: gold)),
                        if (_events[i].text.isNotEmpty) Text(_events[i].text),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => setState(() => _events.removeAt(i)),
                    icon: const Icon(Icons.delete_outline, color: danger),
                  ),
                ],
              ),
              padding: const EdgeInsets.fromLTRB(12, 4, 4, 4),
            ),
          _sectionTitle('HAT / GÖREV / TREN DEĞİŞİMİ'),
          FilledButton.icon(
            onPressed: _addChange,
            icon: const Icon(Icons.add),
            label: const Text('DEĞİŞİM EKLE'),
          ),
          for (var i = 0; i < _changes.length; i++)
            panel(
              Row(
                children: [
                  Text(_changes[i].time,
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (_changes[i].place.isNotEmpty)
                          Text(_changes[i].place, style: const TextStyle(color: gold)),
                        if (_changes[i].prevTrain.isNotEmpty || _changes[i].newTrain.isNotEmpty)
                          Text('${_changes[i].prevTrain} → ${_changes[i].newTrain}'),
                        if (_changes[i].text.isNotEmpty) Text(_changes[i].text),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => setState(() => _changes.removeAt(i)),
                    icon: const Icon(Icons.delete_outline, color: danger),
                  ),
                ],
              ),
              padding: const EdgeInsets.fromLTRB(12, 4, 4, 4),
            ),
          _sectionTitle('MAKİNİSTLER'),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _crewCtl,
                  decoration: const InputDecoration(labelText: 'Ad soyad'),
                  onSubmitted: (_) => _addCrew(),
                ),
              ),
              IconButton(onPressed: _addCrew, icon: const Icon(Icons.add_circle, color: gold, size: 32)),
            ],
          ),
          Wrap(
            spacing: 8,
            children: [
              for (var i = 0; i < _crew.length; i++)
                Chip(
                  label: Text(_crew[i]),
                  onDeleted: () => setState(() => _crew.removeAt(i)),
                ),
            ],
          ),
          const SizedBox(height: 10),
          TextField(
              controller: _note,
              decoration: const InputDecoration(labelText: 'Açıklama'),
              maxLines: 2),
          _sectionTitle('HESAPLAMA SONUÇLARI'),
          panel(
            c.ok || c.total > 0
                ? Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          stat('TOPLAM', hhmm(c.total)),
                          stat('4011', hhmm(c.minutes4011)),
                          if (_use45) stat('45', hhmm(c.minutes45)),
                          if (_useSef) stat('ŞEF', hhmm(c.minutesSef)),
                          stat('GECE', hhmm(c.night), color: const Color(0xFF8AA4FF)),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text('Toplam görev süresi: ${formatMinutes(c.total)}'),
                      Text('Gece çalışması (20:00–06:00): ${formatMinutes(c.night)}'),
                      Text('Gece sınırı: ${formatMinutes(nightLimitMinutes)}'),
                      Text('Gece çalışma aşımı: ${formatMinutes(c.nightExcess)}'),
                      for (final er in c.errors)
                        Padding(
                          padding: const EdgeInsets.only(top: 6),
                          child: Text(er, style: const TextStyle(color: danger)),
                        ),
                    ],
                  )
                : Text(c.errors.first, style: const TextStyle(color: danger)),
          ),
          for (final w in warnings)
            panel(
              Text(w, style: const TextStyle(color: Colors.black87)),
              color: const Color(0xFFFFE08A),
            ),
          const SizedBox(height: 12),
          FilledButton(onPressed: _save, child: const Text('HESAPLA & KAYDET')),
        ],
      ),
    );
  }
}
